.. _authorization_module:

:mod:`pyramid.authorization`
-------------------------------

.. automodule:: pyramid.authorization

  .. autoclass:: ACLAuthorizationPolicy

