tutorial README
