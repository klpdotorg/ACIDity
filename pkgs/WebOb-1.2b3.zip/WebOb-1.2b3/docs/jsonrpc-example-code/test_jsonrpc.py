if __name__ == '__main__':
    import doctest
    doctest.testfile('test_jsonrpc.txt')
