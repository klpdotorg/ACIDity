def test_one():
    assert 1 == 1

def test_one_two():
    assert 2 == 1

def test_foo():
    pass