This is a little py.test plugin for using the figleaf package
to obtain python coverage information. 

In order to install this plugin and have py.test automatically
integrate it you need setuptools or distribute.  You can then
issue::

    python setup.py install 

which will install dependencies as well. 

For more info on py.test go here:

    http://pytest.org

Have fun, 

holger krekel
