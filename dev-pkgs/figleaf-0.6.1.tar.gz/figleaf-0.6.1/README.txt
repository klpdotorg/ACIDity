This is figleaf, a code coverage recording and analysis package for Python.

See

	http://darcs.idyll.org/~t/projects/figleaf/doc/

for more information.

C. Titus Brown
titus@idyll.org
