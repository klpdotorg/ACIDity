"""
A simple little program for testing figleaf command stuff.
"""
import sys
print 'ARGV:', '::'.join(sys.argv[1:])

a = 1
b = 2
c = 3

if 1:
    print 'hello, world!'
else:
    print 'goodbye'
