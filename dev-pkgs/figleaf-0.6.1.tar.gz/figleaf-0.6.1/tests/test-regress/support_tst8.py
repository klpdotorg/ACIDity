def x():
    1

if 0:
    pass
elif 2:
    pass
