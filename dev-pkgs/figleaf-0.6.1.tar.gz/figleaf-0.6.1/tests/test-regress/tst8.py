import support_tst8

print 'hi'
support_tst8.x()
