def f(self):
    if self==1:
        pass
    elif self.m('fred'):
        pass
    elif (g==1) and (b==2):
        pass
    elif self.m('fred')==True:
        pass
    elif ((g==1) and (b==2))==True:
        pass
    else:
        pass
