a = 1

def g():
    global a
    a = 2

g()
