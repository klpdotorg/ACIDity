print 'hello, world'

if 1 \
   and 1:
    print 'hello, world'

if 1 \
   and 0:
    print 'yo'
