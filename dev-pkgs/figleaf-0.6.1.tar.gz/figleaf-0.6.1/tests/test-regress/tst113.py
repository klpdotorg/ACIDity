def fn():
    a = 1
    return (
        a +
        1)
        
x = fn()
assert(x == 2)
