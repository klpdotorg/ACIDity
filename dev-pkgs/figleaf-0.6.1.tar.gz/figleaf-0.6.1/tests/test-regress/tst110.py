print "hello, world!"
print ("hey: %d" %
    17)
print "goodbye"
print "hello, world!",
print ("hey: %d" %
    17),
print "goodbye",
