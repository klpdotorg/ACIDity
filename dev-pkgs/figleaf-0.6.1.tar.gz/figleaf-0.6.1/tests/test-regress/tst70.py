def fn(foo):      #pragma: NO COVER
    a = 1
    b = 2
    c = 3
    
x = 1
assert x == 1
