d = {
    'foo': 1+2,
    'bar': (lambda x: x+1)(1),
    'baz': str(1),
}
e = { 'foo': 1, 'bar': 2 }
