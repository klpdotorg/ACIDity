if 1:
    pass
elif 0:
    print 'howdy'
else:
    print 'hello'

if 0:
    pass
elif 1:
    print 'howdy'
else:
    print 'hello'

if 0:
    pass
elif 0:
    print 'howdy'
else:
    print 'hello'
