import string
if 1 == 2:
    from sys import path
a = 1
