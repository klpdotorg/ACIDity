try:
    raise Exception(
        "hello %d" %
        17)
except:
    pass
