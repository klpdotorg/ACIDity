a = 0
try:
    a = 1
except:
    a = 99
assert a == 1
