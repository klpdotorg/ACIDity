print 'hello, world'
