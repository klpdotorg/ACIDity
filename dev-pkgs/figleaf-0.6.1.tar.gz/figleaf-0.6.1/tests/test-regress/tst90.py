class obj: pass
o = obj()
o.foo = (1 + 2)
o.foo = (1 +
    2)
o.foo = \
    1
