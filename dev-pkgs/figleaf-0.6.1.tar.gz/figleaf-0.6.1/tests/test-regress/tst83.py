a = 1; b = 2
if a == 99:
    a = 4   # -cc
    b = 5
    c = 6   # -xx
assert a == 1 and b == 2
