from sys import \
    *
assert len(path) > 0
