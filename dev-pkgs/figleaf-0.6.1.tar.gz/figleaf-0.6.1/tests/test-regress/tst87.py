assert (1 + 2)
assert (1 + 
    2)
assert (1 + 2), 'the universe is broken'
assert (1 +
    2), \
    'something is amiss'
