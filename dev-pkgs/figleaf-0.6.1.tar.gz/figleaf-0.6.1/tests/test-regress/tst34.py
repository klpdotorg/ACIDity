def foo(
    a,
    b
    ):
    ''' docstring
    '''
    return a+b
    
x = foo(17, 23)
assert x == 40
