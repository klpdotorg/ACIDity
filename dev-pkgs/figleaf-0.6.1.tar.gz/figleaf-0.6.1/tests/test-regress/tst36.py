a = 1
if a == 1:
    x = 3
assert x == 3
if (a == 
    1):
    x = 7
assert x == 7
