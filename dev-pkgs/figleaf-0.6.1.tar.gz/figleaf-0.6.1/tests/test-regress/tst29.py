a = 0
for i in [1,
    2,3,4,
    5]:
    a += i
assert a == 15
