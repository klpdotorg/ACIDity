a = 1
b = 2

c = 4
# Nothing here
d = 6
