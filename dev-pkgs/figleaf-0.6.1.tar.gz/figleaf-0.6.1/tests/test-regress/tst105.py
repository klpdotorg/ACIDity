import sys, \
    sys as s
assert s.path == sys.path
