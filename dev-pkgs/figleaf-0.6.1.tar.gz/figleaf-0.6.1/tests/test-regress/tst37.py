a = 1
if a == 1:
    x = 3
else:
    y = 5
assert x == 3
