a = 0
try:
    a = 1
finally:
    a = 99
assert a == 99
