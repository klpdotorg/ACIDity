a = 1; b = 2; c = 3;
if (
    a != 1
    ):
    x = 3
elif (
    b == 2
    ):
    y = 5
else:
    z = 7
assert y == 5
