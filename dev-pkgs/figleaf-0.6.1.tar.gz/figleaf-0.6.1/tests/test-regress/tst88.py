a = 1
a,b,c = 7,8,9
assert a == 7 and b == 8 and c == 9
