a = 1; b = 2
if a == 1:
    if b == 2:
        x = 4
    else:
        y = 6
else:
    z = 8
assert x == 4
