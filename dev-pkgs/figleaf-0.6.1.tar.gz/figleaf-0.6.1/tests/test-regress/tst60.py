a = 3; b = 0
while a:
    b += 1
    a -= 1
else:
    b = 99
assert a == 0 and b == 99
