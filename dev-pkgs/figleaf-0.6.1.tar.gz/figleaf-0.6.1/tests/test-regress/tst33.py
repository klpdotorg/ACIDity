a = 99
def foo():
    ''' docstring
    '''
    return 1
    
a = foo()
assert a == 1
