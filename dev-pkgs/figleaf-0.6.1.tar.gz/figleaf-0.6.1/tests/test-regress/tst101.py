import string
from sys import path
a = 1
