class obj: pass
o = obj()
o.a, o.b = (1 + 2), 3
o.a, o.b = (1 +
    2), (3 +
    4)
o.a, o.b = \
    1, \
    2
