for x in range(10):
    print "Hello"
    break
    print "Not here"
