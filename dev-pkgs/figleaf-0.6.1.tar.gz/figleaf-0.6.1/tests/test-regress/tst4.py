try:
   raise Exception(
                    "hello %d" %
                    17)
finally:
   pass
