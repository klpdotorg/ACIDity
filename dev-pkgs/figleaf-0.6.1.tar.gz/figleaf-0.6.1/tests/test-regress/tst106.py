from sys import path, \
    path as p
assert p == path
