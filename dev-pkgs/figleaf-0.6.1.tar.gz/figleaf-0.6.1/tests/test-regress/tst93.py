for x in range(10):
    print "Hello"
    continue
    print "Not here"
