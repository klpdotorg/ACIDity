a = 0
for i in [1,2,3,4,5]:     #pragma: NO COVER
    a += i
assert a == 15
