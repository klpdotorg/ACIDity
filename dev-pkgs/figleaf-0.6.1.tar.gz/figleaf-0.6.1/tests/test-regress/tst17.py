l = [
    2*i for i in range(10)
    if i > 5
    ]
assert l == [12, 14, 16, 18]
