# used by test_include.py

print 'hello, world'

def x():
    a = 5
    print a

x()


