def f():
    pass

#
