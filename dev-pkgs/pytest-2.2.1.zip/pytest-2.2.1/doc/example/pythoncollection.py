
# run this with $ py.test --collectonly test_collectonly.py
#
def test_function():
    pass

class TestClass:
    def test_method(self):
        pass
    def test_anothermethod(self):
        pass
